# Manhunt Radar

Prototype web pour une partie entre amis. Android et iPhone peuvent l'ouvrir dans leur navigateur.

## Fonctionnement prévu
- Une partie possède un code à 6 caractères.
- Chaque joueur choisit son pseudo et son équipe : chasseurs ou fugitifs.
- Les fugitifs envoient un point GPS ponctuel toutes les 5 minutes, uniquement si la page est ouverte et la permission GPS accordée.
- Les points sont visibles pour les chasseurs pendant 60 secondes, puis masqués et supprimés au mieux.
- Le site ne suit pas et n'enregistre pas de trajet continu.

## Configuration Firebase déjà intégrée
Le fichier `index.html` contient la configuration publique de l'application web Firebase du projet `manhunt-f8b45`, dont l'URL Realtime Database.

### À faire dans Firebase avant un test réel
1. Authentication → Sign-in method : activer **Anonymous**.
2. Realtime Database → Rules : copier le contenu de `database.rules.json`, puis publier les règles.
3. Vérifier que les règles publiées sont bien celles de ce fichier. Le fait d'avoir le fichier dans GitHub ne publie pas automatiquement les règles Firebase.

### Publication GitHub Pages
1. Mettre `index.html` à la racine du dépôt GitHub, en remplaçant le fichier placeholder existant.
2. Dans Settings → Pages, choisir `Deploy from a branch`, branche `main`, dossier `/(root)`.
3. Attendre la fin du déploiement puis recharger le site. Si l'ancienne page reste affichée, faire un rechargement forcé ou patienter quelques minutes.

## Limites importantes
- Ceci est un prototype, pas un service audité professionnellement. Tester d'abord avec de fausses positions.
- Les navigateurs mobiles peuvent suspendre le site en arrière-plan. Garder la page ouverte et l'écran actif pendant la partie.
- Les positions GPS sont des données sensibles : ne partagez le code de partie qu'avec les joueurs. Utilisez uniquement une zone autorisée, avec le consentement de tous.
- Les clés de configuration Web Firebase sont normalement publiques; la sécurité repose sur les règles de la base et les contrôles d'accès.
- Les règles Firebase doivent être vérifiées et testées avant une partie réelle.
