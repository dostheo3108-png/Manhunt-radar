# Manhunt Radar (prototype)

Petit site web responsive Android/iPhone pour un Manhunt : les fugitifs envoient un **point GPS unique** toutes les 5 minutes; les chasseurs peuvent le voir pendant 60 secondes. Ce n'est pas du suivi GPS continu et aucun itinéraire n'est calculé ou enregistré.

## Important avant utilisation

- Ce projet est un prototype à configurer et tester; il n'est pas déjà hébergé.
- La capture GPS dans un navigateur mobile est plus fiable si la page reste ouverte au premier plan. iOS/Android peuvent suspendre le site en arrière-plan ou lorsque le téléphone est verrouillé.
- Un site web ne peut pas garantir l'envoi à la seconde près si le téléphone n'a plus de réseau, si le GPS est refusé ou si le navigateur est suspendu.
- Le code de partie est un secret partagé. Ne le publiez pas. Ce prototype est destiné à une partie privée entre personnes consentantes, pas à un suivi clandestin.
- Les règles de base autorisent un joueur à créer ou modifier sa fiche joueur avec son propre compte. Avant un usage public, il faut renforcer les règles (notamment verrouiller l'équipe après la connexion, limiter les joueurs à 10, et ajouter une fonction de fermeture/suppression de partie).

## 1. Créer le projet Firebase gratuit

1. Va sur https://console.firebase.google.com/ et crée un projet.
2. Dans Authentication > Sign-in method, active **Anonymous**.
3. Dans Realtime Database, crée une base (choisis une région proche, par exemple Europe). Copie l'URL de la base.
4. Dans Authentication > Sign-in method, vérifie que **Anonymous** est activé.
5. Dans Realtime Database > Rules, colle le contenu de `database.rules.json`, puis publie les règles. Les règles limitent la lecture des points aux chasseurs et refusent la lecture des points expirés. Chaque joueur peut aussi lire sa propre fiche, ce qui est nécessaire pour rejoindre une partie.
6. Dans Project settings > Your apps, ajoute une application Web (`</>`) si ce n'est pas déjà fait. La configuration Firebase fournie a été insérée dans `index.html`.
7. Vérifie que l'URL `databaseURL` dans `index.html` correspond à l'URL affichée dans Realtime Database.

## 2. Héberger gratuitement

Option simple : GitHub Pages.
1. Crée un dépôt GitHub privé ou public nommé par exemple `manhunt-radar`.
2. Ajoute `index.html` (le fichier doit être à la racine). Tu peux garder README et les règles dans le dépôt, mais ne mets jamais de clé de compte de service ou de clé privée Firebase.
3. Dans Settings > Pages, choisis de publier depuis la branche principale et le dossier `/root` (ou `/`).
4. Ouvre l'URL HTTPS fournie par GitHub Pages. Le GPS nécessite un contexte sécurisé HTTPS.

Tu peux aussi utiliser un autre hébergeur statique HTTPS.

## 3. Lancer une partie

1. Une personne crée la partie et partage le code à ses 9 amis.
2. Chaque joueur ouvre le site, entre un pseudo, sélectionne son équipe et rejoint avec le code.
3. Chaque fugitif accepte la demande de localisation du navigateur.
4. L'horaire des signaux est calé sur l'heure de création de la partie. Après le premier intervalle complet, un fugitif actif envoie un point GPS unique. Le point expire après 60 secondes.

## Architecture et limites

- Firebase Authentication anonyme identifie chaque navigateur sans demander de compte.
- Firebase Realtime Database stocke les membres et le dernier point temporaire par fugitif.
- Leaflet affiche une carte OpenStreetMap.
- Les règles limitent la lecture des points aux chasseurs et seulement tant que le point n'a pas expiré côté serveur.
- Le site tente de supprimer le point de la base après 60 secondes. Si le navigateur est suspendu ou hors ligne, le point peut rester stocké, mais les règles refusent sa lecture une fois l'heure d'expiration passée.
- Ce prototype ne supprime pas automatiquement les parties abandonnées et n'est pas audité comme système de sécurité. Testez-le avec des coordonnées fictives avant d'utiliser vos vraies positions.


## Configuration de ce paquet

La configuration du projet `manhunt-f8b45` et l'URL Realtime Database fournies ont été insérées dans `index.html`. La configuration web Firebase (dont `apiKey`) est destinée à être présente dans le client; la protection dépend des règles de sécurité et de l'authentification, pas du secret de cette configuration. Les fichiers ont été vérifiés pour la cohérence des paramètres et la syntaxe JSON des règles, mais la connexion réelle à Firebase n'a pas été testée depuis un navigateur connecté.
